#ifndef _VESPA_H_
#define _VESPA_H_

#include <ESP8266WiFi.h>
#include <PubSubClient.h>
#include <ESP8266HTTPClient.h>
#include <ESP8266httpUpdate.h>

/* Prerequisites : 
  Wifi, HTTP and MQTT libraries,
  Change max packet size for mqtt in PubSub client library #define MQTT_MAX_PACKET_SIZE 2048
*/

typedef struct vespa_config_s {
    char wifi_ssid[32];
    char wifi_password[32];
    char vesp_admin_url[32];
    char userid[32];
    char password[32];
    char tenantid[32];
} vespa_config_t;

typedef struct vespa_s {
    vespa_config_t vespa_config;
    char http_tenant_url[64];
    char token[256];
    char data[512];
    char deviceid[32];
    char swu_url[64];
    char mqtt_url[64];
    char mqtt_topic[64];
    char mqtt_msg[512];
    short mqtt_port;
    long lastMsg = 0;
} vespa_t;


void vespa_login(struct vespa_s * vespa);
void vespa_device_authenticate(struct vespa_s * vespa);
void vespa_capability(struct vespa_s * vespa);
int check_vespa_ota_update(struct vespa_s * vespa);
int vespa_update_software(struct vespa_s * vespa);

#endif
