#include <vespa.h>

HTTPClient http;
#define BOOT_AFTER_UPDATE false

//Call vespa_init(), or fill admin API data before calling login API
void vespa_login(struct vespa_s * vespa)
{
    // Call login api using fixed predefined admin api using email and tenantid or password
    char login_api[64];
    char api_data[128];
    char mqtt_url[64];
    memset(login_api,0,sizeof(login_api));
    memset(api_data,0,sizeof(api_data));
    sprintf(login_api,"http://%s/user/authenticate",vespa->vespa_config.vesp_admin_url);
    Serial.println(login_api);

    http.begin(login_api);    
    http.addHeader("Content-Type", "application/json");  //Specify content-type header   
    sprintf(api_data, "{ \"email\": \"%s\",\"password\": \"%s\",\"provider\": \"EMAIL\"}", vespa->vespa_config.userid, vespa->vespa_config.password);   //Send the request
    int httpCode = http.POST(api_data);
    Serial.println(api_data);
    String payload = http.getString();   //Get the response payload
    Serial.print("Login api return code = "); Serial.println(httpCode);            //Print HTTP return code
    // Serial.println(payload);             //Print request response payload
    payload.toCharArray(vespa->data,sizeof(vespa->data));
    // Parse and Store tenant urls and auth token for next api
    strtok(vespa->data,"=");
    strcpy(vespa->http_tenant_url, strtok(NULL,",")); //Storing http tenant url here
    strtok(NULL,"=");
    strcpy(mqtt_url, strtok(NULL,","));               //Storing mqtt url here
    strtok(NULL,"=");
    strcpy(vespa->swu_url, strtok(NULL,","));                //Storing software update url here
    strtok(NULL,"=");
    strcpy(vespa->token, strtok(NULL,"\n"));          //Storing http token for all further rest apis   
    // Separate MQTT URL and Port
    strcpy(vespa->mqtt_url, strtok(mqtt_url,":"));
    vespa->mqtt_port = atoi(strtok(NULL, "\n"));

    Serial.print("Tenant HTTP Url   = "); Serial.println(vespa->http_tenant_url);
    Serial.print("Device Auth token = "); Serial.println(vespa->token);    
    Serial.print("SWU Url           = "); Serial.println(vespa->swu_url);
    Serial.print("MQTT Url          = "); Serial.println(vespa->mqtt_url);
    Serial.print("MQTT Port         = ");  Serial.println(vespa->mqtt_port);
    http.end();  //Close connection
}

//Call auth API After login api only
void vespa_device_authenticate(struct vespa_s * vespa)
{
    //Prepare device Authenticate api to autenticate device. Here tenantid is UI generated authcode.
    String tenantapi = String(String(vespa->http_tenant_url) + "/device/auth/"+String(vespa->vespa_config.tenantid));
    Serial.print("Tenant http API = ");Serial.println(tenantapi);
       
    String Authtoken = String("Bearer "+ String(vespa->token));
    Serial.print("Bearer token = ");Serial.println(Authtoken);
    
    /* Call device Authenticate api to Autenticate with vesp platform
     using auth token, authcode and http tenant url */
    http.begin(tenantapi);
    http.addHeader("Authorization", Authtoken); //Specify Auth token
    http.addHeader("Content-Type", "application/json");  //Specify content-type header  
    int httpCode = http.GET();
    String payload = http.getString();  // Get the response payload    
    Serial.print("Auth api return code = ");Serial.println(payload);     // Print request response payload    
    //Parse and store device id and tenantid provided in reponse of authenticate, needed for mqtt dynamic topic creation.
    payload.toCharArray(vespa->data,sizeof(vespa->data));
    // Parse and Store device id here
    strtok(vespa->data,"=");
    strcpy(vespa->deviceid, strtok(NULL,","));
    //Serial.println(vespa->deviceid);
    http.end();  
}

void vespa_capability(struct vespa_s * vespa)
{
    /* Capability API */
    String capabilityApi = String(String(vespa->http_tenant_url)+"/device/capability/"+String(vespa->deviceid));
    Serial.print("Capability api = "); Serial.println(capabilityApi);
    String Authtoken = String("Bearer "+ String(vespa->token) );
    http.begin(capabilityApi);
    http.addHeader("Authorization", Authtoken); //Specify Auth token
    http.addHeader("Content-Type", "application/json");  //Specify content-type header
    int httpCode = http.POST("{ \"devicetype\": \"MicroController\"}");   //Send the request
    String payload = http.getString();  // Get the response payload
    Serial.print("Capability api return code = ");Serial.println(httpCode);    // Print HTTP return code    
    //Serial.println(payload);     // Print request response payload
    payload.remove(0,10);    
    payload.toCharArray(vespa->mqtt_topic,sizeof(vespa->mqtt_topic));
    //Serial.println(vespa->mqtt_topic);
    http.end();
}

int vespa_update_software(struct vespa_s * vespa)
{
    int retCode = 0;
    int dist_id = 0;
    char * token;
    char ota_resp[512]; 
    char api_data[256];
    HTTPClient http_ota;

    token = strstr(vespa->data,"http");
    token = strtok(token,"\"");
    Serial.println(token); //HTTP_GET URL for knowing artifact URL
    http_ota.begin(token);
    int httpCode = http_ota.GET();
    String payload = http_ota.getString();  // Get the response payload
    //Get dist_id from the response data received
    String idx = payload.substring(7,payload.indexOf("\"",7));
    dist_id = atoi(idx.c_str());
    Serial.print("Distribution id = ");Serial.println(dist_id);
    // Store complete payload as string for processing
    payload.toCharArray(vespa->data,sizeof(vespa->data));
    http_ota.end();

    Serial.print("Recevied payload = ");Serial.println(vespa->data);
    //Get Artifact URL now
    token = strstr(vespa->data,"http");
    token = strstr(token,"href");
    token = strstr(token,"http");
    token = strtok(token,"}");
    token = strtok(token,"\"");
    Serial.print("Update image URL = "); Serial.println(token);
    Serial.println("Updating Software now ..."); 

    ESPhttpUpdate.rebootOnUpdate(BOOT_AFTER_UPDATE);        
    t_httpUpdate_return ret  = ESPhttpUpdate.update(token);
    switch(ret)
    {
        case HTTP_UPDATE_FAILED:
            Serial.printf("HTTP_UPDATE_FAILED Error (%d): %s\n",  ESPhttpUpdate.getLastError(), ESPhttpUpdate.getLastErrorString().c_str());
            retCode = -1;
        break;
        case HTTP_UPDATE_NO_UPDATES:
            Serial.println("HTTP_UPDATE_NO_UPDATES");
            retCode = -1;
        break;
        case HTTP_UPDATE_OK:
            Serial.println("HTTP_UPDATE_OK");
        break;
    }

    if (ret == HTTP_UPDATE_OK)
    {
        /* Respond back that update is success, to update rollout status in server. */
        sprintf(ota_resp,"%s/default/controller/v1/%s/deploymentBase/%d/feedback",vespa->swu_url, vespa->deviceid, dist_id);
        http_ota.begin(ota_resp);    
        http_ota.addHeader("Content-Type", "application/json");  //Specify content-type header  
        sprintf(api_data,"{\"id\":\"%d\",\"time\":\" \",\"status\":{\"result\":{\"finished\":\"success\"},\"execution\":\"closed\",\"details\":[\"Success Feedback\"] } }", dist_id);
        Serial.println(api_data);
        httpCode = http_ota.POST(api_data);
        Serial.print("OTA update response return code = ");Serial.println(httpCode);//Print HTTP return code
        //String ota_resp_buf = http_ota.getString(); //Get the response payload
        //Serial.print("OTA update response payload     = ");Serial.println(ota_resp_buf);     //Print reply payload
        http_ota.end();
    }

    return retCode;
}

int check_vespa_ota_update (struct vespa_s * vespa)
{
    int ret = 0;
    HTTPClient http_ota;
    char ota_check_api[128];

    sprintf(ota_check_api,"%s/default/controller/v1/%s",vespa->swu_url,vespa->deviceid);
    //Serial.println(ota_check_api);

    http_ota.begin(ota_check_api);
    int httpCode = http_ota.GET();
    String payload = http_ota.getString();  // Get the response payload
    //Serial.print("OTA_check_payload"); Serial.println(payload);
    payload.toCharArray(vespa->data,sizeof(vespa->data));
    http_ota.end();

    if(strstr(vespa->data,"deploymentBase") != NULL)
        ret = 1;
    return ret;
}

