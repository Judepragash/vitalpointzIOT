#ifndef _VESPA_H_
#define _VESPA_H_

#include <string.h>
#include <stdlib.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"
#include "esp_system.h"
#include "nvs_flash.h"
#include "app_wifi.h"

#include "cJSON.h"
#include "esp_http_client.h"

#if CONFIG_SSL_USING_WOLFSSL
#include "lwip/apps/sntp.h"
#endif

#define ID_LEN 32
#define PASSWD_LEN 32
#define VESP_TOKEN_LEN 32
#define URL_LEN 64
#define HASH_LEN 64
#define MQTT_TOPIC_LEN 64
#define DEV_NAME_LEN 64
#define HTTP_TOKEN_LEN 256
#define HTTP_RECV_BUFFER_LEN 512
#define CA_KEY_LEN 2048
#define CERT_LEN 5120
static const char *TAG = "VESPA";

/* Prerequisites : 
  Wifi, HTTP and MQTT libraries from corresponding platfrom and Change APIs accordingly,
  Change max packet size for mqtt to 2048.
  Need 8192 buffer to hold response from capability API.
  cJSON parser library is used for response parsing.
*/

typedef struct vespa_config_s {
    char vesp_url[URL_LEN];
    char userid[ID_LEN];
    char password[PASSWD_LEN];
    char tenant_token[VESP_TOKEN_LEN];
    char hash[HASH_LEN];
} vespa_config_t;

typedef struct vespa_mqtt_s {
    char mqtt_url[URL_LEN];
    char mqtt_topic[MQTT_TOPIC_LEN];
    short mqtt_port;
    void * mqtt_handle;
} vespa_mqtt_t;

/* Main vespa dev/handle structure */
typedef struct vespa_s {
    char userid[ID_LEN];
    char deviceid[ID_LEN];
    char devicename[DEV_NAME_LEN];
    char devicehash[HASH_LEN];
    char device_authcode[VESP_TOKEN_LEN]; //tenantid may be used as authcode
    char tenantid[ID_LEN];
    char password[PASSWD_LEN];
    char http_token[HTTP_TOKEN_LEN];
    char http_data[HTTP_RECV_BUFFER_LEN];
    char vesp_admin_url[URL_LEN];
    char http_tenant_url[URL_LEN];
    char swu_url[URL_LEN];
    vespa_mqtt_t vespa_mqtt;
    char client_key[CA_KEY_LEN];
    char client_ca[CA_KEY_LEN];
    char client_cert[CERT_LEN];
} vespa_t;

#endif
